<h1>Selamat Datang di Dashboard</h1>

ID : <?php echo $pasien1->id?>
<br>Kode Pasien : <?=$pasien1->kode?>
<br>Nama Pasien : <?=$pasien1->nama?>
<br>Gender Pasien : <?=$pasien1->jenisKelamin()?>
